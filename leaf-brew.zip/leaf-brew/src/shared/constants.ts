export const LOCAL_STORAGE_KEYS = {
  AUTH_PROFILE: 'auth_profile',
  USER_PROFILE: 'user_profile',
  USER_DATA: 'user_data',
  // DELIVERY_PERSON_DATA: 'delivery_person_data',
  // SETTING: 'user_setting',
  // NAV_SETTING: 'user_nav_setting',
  // TAG_DATA: 'tag_data',
  // ATTENDANCE_DATA: 'attendance_data',
}

export const APPLICATION_DATA = {
  CURRENT_VERSION: '1.0.0 ~ alpha',
  LAST_UPDATED: '13 August 2025',
  APP_NAME: 'Leaf Brew',
  APP_DESCRIPTION: 'A tea bidding site for discovering and acquiring premium teas.',
  DEVELOPER_NAME: 'Harsh Gupta',
  DEVELOPER_EMAIL: 'harshgupta.code1@gmail.com'
};

export const DEVELOPER = {
  IS_DEV_ENVIRONMENT: false, // Set to true if you are in a development environment
  DEV_PATH_PREFIX: 'dev/',
  IS_STAGE_ENVIRONMENT: false, // Set to true if you are in a staging environment
  STAGE_PATH_PREFIX: 'stage/',
  USE_LOCAL_DATABASE: false, // Set to true to use local JSON files for development
  LOCAL_DATABASE_URL: 'assets/json/local-database.json',
};

export const DEFAULT_NAV_OBJECT = (() => {
  const obj: any = {
    'new-sheet': {
      title: 'New Offer Sheet',
      key: 'new-sheet',
      imgSrc: 'assets/images/icons/new-file.png',
      bgColor: '#E0E7FF',
      visible: true,
      enable: true,
    },
    'active-sheet': {
      title: 'Active Sheet',
      key: 'active-sheet',
      imgSrc: 'assets/images/icons/active-file.png',
      bgColor: '#DEFDE0',
      visible: true,
      enable: true
    },
    'closed-sheet': {
      title: 'Closed Sheet',
      key: 'closed-sheet',
      imgSrc: 'assets/images/icons/delete-file.png',
      bgColor: '#FFEFD5',
      visible: true,
      enable: true
    },
    reports: {
      title: 'Reports',
      key: 'reports',
      imgSrc: 'assets/images/icons/analysis.png',
      bgColor: '#FFE4E1',
      visible: true,
      enable: true
    },
    profile: {
      title: 'Profile',
      key: 'profile',
      imgSrc: 'assets/images/icons/profile.png',
      bgColor: '#E0F7FA',
      visible: true,
      enable: true
    },
    logout: {
      title: 'Logout',
      key: 'logout',
      imgSrc: 'assets/images/icons/logout.png',
      bgColor: '#FFE4E1',
      visible: true,
      enable: true
    }
  };

  return obj;
})();