import { Injectable } from "@angular/core";
import { AccountService } from "../services/account.service";
import { Router } from "@angular/router";
import { getAuth, onAuthStateChanged } from "firebase/auth";
import { FirebaseService } from "../services/firebase.service";
import { NotificationService } from "../services/notification.service";
import { MyUser } from "../assets/models/MyUser";

@Injectable({
  providedIn: 'root'
})
export class authGuard {
  constructor(
    private accountService: AccountService,
    private firebaseService: FirebaseService,
    private notificationService: NotificationService,
    private router: Router
  ) { }

  canActivate(): Promise<boolean> { // return false when user is not logged in and open auth page
    if (this.accountService.hasUserData() && this.accountService.allowUser()) {
      return Promise.resolve(true);
    } else if (!this.accountService.allowUser()) {
      this.notificationService.notAuthorized();
      this.accountService.signOut();
      return Promise.resolve(false);
    }

    const auth = getAuth();
    return new Promise((resolve) => {
      onAuthStateChanged(auth, (user: any) => {
        if (user) {
          const userId = user.uid;
          this.firebaseService.getloggedInUserData(userId).then((userData: MyUser) => {
            if (userData.data) {

              if (userData.data.importantTimes)
                userData.data.importantTimes.lastSeen = Date.now();

              this.accountService.setUserData(userData);
              this.accountService.setAuthData({
                user: {
                  uid: user.uid,
                  createdAt: user.metadata.createdAt,
                  lastLoginAt: user.metadata.lastLoginAt
                }
              });
              if (userData.data.permission?.blocked) {
                this.notificationService.accountBlocked();
                this.accountService.signOut();
                resolve(false);
              } else if (userData.data.userType === 'unknown' || !userData.data.permission?.verified) {
                this.notificationService.accountNotApproved();
                this.accountService.signOut();
                resolve(false);
              } else {
                this.notificationService.welcomeBack(userData.data.fullName); // welcome back notification
                resolve(true);
              }
            } else {
              this.router.navigate(['/auth']);
              resolve(false); // no data found in database // this will disable the route in route.ts file if user is not logged in and application will navigate to /auth
            }
          });
        } else {
          this.router.navigate(['/auth']);
          resolve(false); // no user logged in // this will disable the route in route.ts file if user is not logged in and application will navigate to /auth
        }
      });
    });
  }

  // canActivate(): Promise<boolean> { // return false when user is not logged in and open auth page
  //   return Promise.resolve(true);
  // }
}