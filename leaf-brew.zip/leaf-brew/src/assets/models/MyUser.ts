export interface MyUser {
    data?: {
        fullName: string
        male?: boolean
        contact: {
            countryCode?: string
            phoneNumber?: string
            email: string
        },
        importantTimes?: {
            lastSeen?: number
            createdOn?: number
        },
        permission?: {
            verified: boolean
            blocked: boolean
        },
        userID?: string
        userType: 'unknown' | 'dealer' | 'admin' | 'manufacturer'
        emailVerified?: boolean
    }
}