export interface DropDown {
    title: string;
    value: string;
}