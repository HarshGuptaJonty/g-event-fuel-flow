export interface Navigation {
    title: string
    key: string
    visible: boolean
    enable: boolean
    hover: boolean
    imgSrc: string
    bgColor: string
    customClass: string
}