export const environment = {
    production: true,
    firebaseConfig: {
        apiKey: "AIzaSyBYSktxhgCfNtP9DEROwaGO-4PGdmzC-1w",
        authDomain: "leaf-brew.firebaseapp.com",
        databaseURL: "https://leaf-brew-default-rtdb.asia-southeast1.firebasedatabase.app",
        projectId: "leaf-brew",
        storageBucket: "leaf-brew.firebasestorage.app",
        messagingSenderId: "467519772615",
        appId: "1:467519772615:web:3f3aaf281e13a6429d2be2",
        measurementId: "G-45FLTVHXKK"
    }
};