import { Component, OnInit } from '@angular/core';
import { UsersService } from '../../../services/users.service';
import { CommonModule } from '@angular/common';
import { MyUser } from '../../../assets/models/MyUser';

@Component({
  selector: 'app-closed-sheet',
  imports: [
    CommonModule
  ],
  templateUrl: './closed-sheet.component.html',
  styleUrl: './closed-sheet.component.scss'
})
export class ClosedSheetComponent implements OnInit {

  constructor(
  ) { }

  ngOnInit(): void {
    
  }
}
