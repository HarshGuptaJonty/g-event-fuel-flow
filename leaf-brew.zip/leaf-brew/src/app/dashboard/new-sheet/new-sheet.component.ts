import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatNativeDateModule } from "@angular/material/core";
import { MatDatepickerModule } from "@angular/material/datepicker";
import { MatTimepickerModule } from '@angular/material/timepicker';
import { MatAutocompleteModule, MatAutocompleteSelectedEvent } from "@angular/material/autocomplete";
import { DropDown } from '../../../assets/models/DropDown';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-new-sheet',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatNativeDateModule,
    MatDatepickerModule,
    MatAutocompleteModule,
    MatTimepickerModule,
    MatButtonModule,
  ],
  templateUrl: './new-sheet.component.html',
  styleUrl: './new-sheet.component.scss'
})
export class NewSheetComponent {

  sheetForm: FormGroup = new FormGroup({
    number: new FormControl('', [Validators.required]),
    name: new FormControl('', Validators.required),
    expiryDate: new FormControl('', Validators.required),
    expiryTime: new FormControl('', Validators.required),
    location: new FormControl('', Validators.required),
    paymentType: new FormControl('', Validators.required),
    contractType: new FormControl('', Validators.required),
    promptDays: new FormControl('', Validators.required),
    squareOff: new FormControl('', Validators.required),
    cashDiscount: new FormControl('', Validators.required),
    privacy: new FormControl('', Validators.required),
    bidIncrement: new FormControl('', Validators.required),
    autoPrice: new FormControl('', Validators.required),
  });

  formStructure: any = [{
    formName: 'number',
    label: 'Offer Sheet Number',
    type: 'numberInput'
  }, {
    formName: 'name',
    label: 'Offer Sheet Name',
    type: 'textInput'
  }, {
    formName: 'expiryDate',
    label: 'Expiry Date',
    type: 'dateInput'
  }, {
    formName: 'expiryTime',
    label: 'Expiry Time',
    type: 'timeInput'
  }, {
    formName: 'location',
    label: 'Offer Sheet Location',
    type: 'dropdown'
  }, {
    formName: 'paymentType',
    label: 'Payment Type',
    type: 'dropdown'
  }, {
    formName: 'contractType',
    label: 'Contract Type',
    type: 'dropdown'
  }, {
    formName: 'promptDays',
    label: 'Prompt Days',
    type: 'numberInput'
  }, {
    formName: 'squareOff',
    label: 'Square Off (in Seconds)',
    type: 'numberInput'
  }, {
    formName: 'cashDiscount',
    label: 'Cash Discount (%)',
    type: 'decimalNumberInput'
  }, {
    formName: 'privacy',
    label: 'Privacy',
    type: 'dropdown'
  }, {
    formName: 'bidIncrement',
    label: 'Bid Increment',
    type: 'numberInput'
  }, {
    formName: 'autoPrice',
    label: 'Auto Price (in Seconds)',
    type: 'numberInput'
  }]

  locationList: DropDown[] = [
    {
      title: 'Kolkata',
      value: 'Kolkata'
    },
    {
      title: 'Delhi',
      value: 'Delhi'
    }
  ]

  paymentTypeList: DropDown[] = [
    {
      title: 'Credit Card',
      value: 'credit_card'
    },
    {
      title: 'Debit Card',
      value: 'debit_card'
    }
  ]

  contractTypeList: DropDown[] = [
    {
      title: 'Fixed',
      value: 'fixed'
    },
    {
      title: 'Variable',
      value: 'variable'
    }
  ]

  privacyList: DropDown[] = [
    {
      title: 'Public',
      value: 'public'
    },
    {
      title: 'Private',
      value: 'private'
    }
  ]

  formJson:any;

  onSaveClick(){
    this.formJson = this.sheetForm.value;
    console.log(this.sheetForm.value);
  }

  getDropDownList(formName: string): DropDown[] {
    switch (formName) {
      case 'location':
        return this.locationList;
      case 'paymentType':
        return this.paymentTypeList;
      case 'contractType':
        return this.contractTypeList;
      case 'privacy':
        return this.privacyList;
      default:
        return [];
    }
  }

  onSelectDropDown(formName: string, value: DropDown) {
    this.sheetForm.get(formName)?.setValue(value.title);
  }

  blockInvalidKeys(blockList: string[], event: KeyboardEvent) {
    // Block '-', '.', 'e', and '+' keys
    if (blockList.includes(event.key)) {
      event.preventDefault();
    }
  }
}
