import { RouterModule, Routes } from "@angular/router";
import { DashboardComponent } from "./dashboard";
import { NgModule } from "@angular/core";
import { ProfileComponent } from "./profile/profile.component";
import { NewSheetComponent } from "./new-sheet/new-sheet.component";
import { ActiveSheetComponent } from "./active-sheet/active-sheet.component";
import { ClosedSheetComponent } from "./closed-sheet/closed-sheet.component";
import { ReportsComponent } from "./reports/reports.component";

const routes: Routes = [
    {
        path: '',
        component: DashboardComponent,
        children: [
            { path: 'new-sheet', component: NewSheetComponent },
            { path: 'active-sheet', component: ActiveSheetComponent },
            { path: 'closed-sheet', component: ClosedSheetComponent },
            { path: 'reports', component: ReportsComponent },
            { path: 'profile', component: ProfileComponent },
            { path: '', redirectTo: 'new-sheet', pathMatch: 'full' }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class DashboardRoutingModule { }