import { Component, OnInit } from '@angular/core';
import { AccountService } from '../../services/account.service';
import { ConfirmationModelService } from '../../services/confirmation-model.service';
import { NotificationService } from '../../services/notification.service';
import { MyUser } from '../../assets/models/MyUser';
import { CommonModule } from '@angular/common';
import { Navigation } from '../../assets/models/Navigation';
import { DEFAULT_NAV_OBJECT } from '../../shared/constants';
import { ActivatedRoute, Router, RouterOutlet } from '@angular/router';

@Component({
    selector: 'app-dashboard',
    imports: [
        CommonModule,
        RouterOutlet
    ],
    templateUrl: './dashboard.html',
    styleUrl: './dashboard.scss'
})
export class DashboardComponent implements OnInit {

    currentNav: Navigation = DEFAULT_NAV_OBJECT.dashboard;
    user!: MyUser;
    menuItemList: Navigation[] = [];
    showMenu = false;

    constructor(
        private router: Router,
        private activeRoute: ActivatedRoute,
        private confirmationModelService: ConfirmationModelService,
        private notificationService: NotificationService,
        private accountService: AccountService
    ) { }

    ngOnInit(): void {
        this.user = this.accountService.getUserData();
        const navObject = DEFAULT_NAV_OBJECT;
        if (this.user.data?.userType === 'dealer') {
            navObject.dealers.visible = false;
            navObject.reports.visible = false;
        } else if (this.user.data?.userType === 'manufacturer') {
            navObject.manufacturers.visible = false;
            navObject.reports.visible = false;
        }
        this.menuItemList = Object.values(navObject) as Navigation[];

        this.activeRoute.firstChild?.url.subscribe((url) => this.currentNav = navObject[url[0]?.path]);
    }

    onMenuItemClick(nav: Navigation) {
        this.currentNav = nav;
        this.showMenu = false;
        if (nav.key === 'logout')
            this.onLogout();
        else
            this.router.navigate(["/dashboard/" + nav.key]);
    }

    onLogout() {
        this.confirmationModelService.showModel({
            heading: 'Log out?',
            message: 'You are trying to logout, are you sure?',
            leftButton: {
                text: 'Logout',
                customClass: this.confirmationModelService.CUSTOM_CLASS?.GREY_RED,
            }, rightButton: {
                text: 'Cancel',
                customClass: this.confirmationModelService.CUSTOM_CLASS?.GREY,
            }
        }).subscribe(result => {
            this.confirmationModelService.hideModel();
            if (result === 'left') {
                this.accountService.signOut();
                this.notificationService.loggedOut();
            }
        });
    }
}