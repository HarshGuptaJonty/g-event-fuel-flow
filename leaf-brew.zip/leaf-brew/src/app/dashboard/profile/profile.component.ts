import { Component, OnInit } from '@angular/core';
import { AccountService } from '../../../services/account.service';
import { MyUser } from '../../../assets/models/MyUser';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-profile',
  imports: [
    CommonModule,
    MatButtonModule
  ],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.scss'
})
export class ProfileComponent implements OnInit {

  myUser!: MyUser;

  constructor(
    private accountService: AccountService
  ) {}

  ngOnInit(): void {
    this.myUser = this.accountService.getUserData();
  }

  onEditProfile(){
    
  }
}
