import { Component } from '@angular/core';

@Component({
  selector: 'app-active-sheet',
  imports: [],
  templateUrl: './active-sheet.component.html',
  styleUrl: './active-sheet.component.scss'
})
export class ActiveSheetComponent {

}
