import { Component, HostListener, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { WindowResizeService } from '../services/window-resize.service';
import { NotificationComponent } from './common/notification/notification';
import { LoaderComponent } from './common/loader/loader';
import { ConfirmationModelComponent } from './common/confirmation-model/confirmation-model';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  imports: [
    RouterOutlet,
    NotificationComponent,
    ConfirmationModelComponent,
    LoaderComponent,
    CommonModule
],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class AppComponent implements OnInit {

  currentScreenWidth = 0;
  isDesktop = false;

  constructor(
    private windowResizeService: WindowResizeService,
  ) { }

  ngOnInit(): void {
    this.onResize();
  }

  @HostListener('window:resize')
  onResize(): void {
    this.windowResizeService.setScreenWidth(window.innerWidth);
    this.isDesktop = this.windowResizeService.currentScreenWidth > 1024;
    this.currentScreenWidth = this.windowResizeService.currentScreenWidth;
  }
}