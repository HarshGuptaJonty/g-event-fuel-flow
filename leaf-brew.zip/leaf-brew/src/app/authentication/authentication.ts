import { CommonModule } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { FormGroup, FormControl, Validators, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { Devices, WindowResizeService } from '../../services/window-resize.service';
import { Subject, takeUntil } from 'rxjs';
import { APPLICATION_DATA } from '../../shared/constants';
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, onAuthStateChanged } from 'firebase/auth';
import { Router } from '@angular/router';
import { FirebaseService } from '../../services/firebase.service';
import { NotificationService } from '../../services/notification.service';
import { AccountService } from '../../services/account.service';
import { FirebaseError } from 'firebase/app';
import { MyUser } from '../../assets/models/MyUser';
import { LoaderService } from '../../services/loader.service';

@Component({
  selector: 'app-authentication',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
  ],
  providers: [
    AngularFireAuth
  ],
  templateUrl: './authentication.html',
  styleUrl: './authentication.scss'
})
export class AuthenticationComponent implements OnInit, OnDestroy {

  message = {
    LOGIN: 'Log in.',
    SIGNUP: 'Sign up.',
    LOGIN_SUBTEXT: 'Login using your registered email.',
    SIGNUP_SUBTEXT: 'Create a new account using a email & password.',
    WELCOME_BACK: 'Welcome Back',
  };

  loginForm: FormGroup = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl('', [Validators.required, Validators.minLength(6)]),
  });

  signupForm: FormGroup = new FormGroup({
    name: new FormControl('', [Validators.required, Validators.minLength(2)]),
    email: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl('', [Validators.required, Validators.minLength(6)]),
    confirmPassword: new FormControl('', [Validators.required, Validators.minLength(6)]),
  });

  isLogin = true;
  showPassword = false;
  devices!: Devices;
  localStorage = APPLICATION_DATA;
  auth: any;

  private destroy$ = new Subject<void>();

  constructor(
    private router: Router,
    private afAuth: AngularFireAuth,
    private accountService: AccountService,
    private firebaseService: FirebaseService,
    private notificationService: NotificationService,
    private windowResizeService: WindowResizeService,
    private loaderService: LoaderService
  ) { }

  ngOnInit(): void {
    this.windowResizeService.checkForWindowSize().pipe(takeUntil(this.destroy$)).subscribe((devicesObj: any) => this.devices = devicesObj);

    this.auth = getAuth();
    onAuthStateChanged(this.auth, (user: any) => {
      if (user) {
        this.firebaseService.getloggedInUserData(user.uid).then((userData: MyUser) => {
          if (userData?.data) {
            if (userData.data.permission?.blocked) {
              this.notificationService.accountBlocked();
              this.accountService.signOut();
            } else if (userData.data.userType === 'unknown' || !userData.data.permission?.verified) {
              this.notificationService.accountNotApproved();
              this.accountService.signOut();
            } else {
              if (userData.data.importantTimes)
                userData.data.importantTimes.lastSeen = Date.now();

              this.accountService.setUserData(userData);
              this.accountService.setAuthData({
                user: {
                  uid: user.uid,
                  createdAt: user.metadata.createdAt,
                  lastLoginAt: user.metadata.lastLoginAt
                }
              });
              this.notificationService.welcomeBack(userData.data.fullName); // welcome back notification
              this.router.navigate(['/dashboard']);
            }
          } else {
            this.notificationService.notAuthorized();
            this.accountService.signOut();
          }
        });
      }
    });
  }

  async onLogin() {
    this.loaderService.showWithLoadingText('Checking account details...', true);
    const { email, password } = this.loginForm.value
    try {
      await signInWithEmailAndPassword(this.auth, email, password);

      this.loaderService.hide();
      this.notificationService.showNotification({
        heading: 'Log in successful.',
        duration: 5000,
        leftBarColor: '#3A7D44'
      });
    } catch (error) {
      console.error("Log in failed:", error);
      this.loaderService.hide();
      if (error instanceof FirebaseError && error.code === 'auth/invalid-credential') {
        this.notificationService.showNotification({
          heading: 'Invalid email or password.',
          duration: 5000,
          leftBarColor: this.notificationService.color.red
        });
      } else
        this.notificationService.somethingWentWrong();
    }
  }

  async onSignup() {
    this.loaderService.showWithLoadingText('Creating account...', true);
    const signupData = this.signupForm.value;
    try {
      const userCredential = await createUserWithEmailAndPassword(this.auth, signupData.email, signupData.password);
      this.loaderService.setLoaderText('Updating database...');
      const userData = userCredential.user as any;

      const newUser: MyUser = {
        data: {
          fullName: signupData.name,
          contact: {
            email: signupData.email
          },
          importantTimes: {
            lastSeen: Date.now(),
            createdOn: Date.now()
          },
          permission: {
            verified: false,
            blocked: true
          },
          userID: userData.uid,
          userType: 'unknown',
          emailVerified: false
        }
      };

      this.firebaseService.setData(`user/${userData.uid}`, newUser).then(() => {
        this.accountService.setAuthData(userData);
        this.accountService.setUserData(newUser);
        this.loaderService.hide();
        this.notificationService.showNotification({
          heading: 'Sign up successful.',
          duration: 5000,
          leftBarColor: '#3A7D44'
        });
      }).catch(() => {
        this.loaderService.hide();
        this.notificationService.somethingWentWrong();
      });
    } catch (error) {
      console.error("Sign up failed:", error);
      this.loaderService.hide();
      if (error instanceof FirebaseError && error.code === 'auth/email-already-in-use') {
        this.notificationService.showNotification({
          heading: 'Email already in use.',
          duration: 5000,
          leftBarColor: this.notificationService.color.red
        });
      } else
        this.notificationService.somethingWentWrong();
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next(); // Emit a value to complete all subscriptions
    this.destroy$.complete(); // Complete the Subject
  }
}

//auth/email-already-in-use