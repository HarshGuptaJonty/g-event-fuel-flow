import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";
import { MyUser } from "../assets/models/MyUser";
import { LOCAL_STORAGE_KEYS } from "../shared/constants";
import { AngularFireAuth } from "@angular/fire/compat/auth";
import { AccountService } from "./account.service";
import { FirebaseService } from "./firebase.service";
import { NotificationService } from "./notification.service";

@Injectable({
    providedIn: 'root'
})
export class UsersService {

    private usersData = new BehaviorSubject<MyUser[]>([]);
    usersData$ = this.usersData.asObservable();

    constructor(
        private afAuth: AngularFireAuth,
        private accountService: AccountService,
        private firebaseService: FirebaseService,
        private notificationService: NotificationService,
    ) {
        const storedUsers = sessionStorage.getItem(LOCAL_STORAGE_KEYS.USER_DATA);
        if (storedUsers)
            this.usersData?.next(JSON.parse(storedUsers));
    }

    setUserData(data: any) {
        this.usersData?.next(data);
        sessionStorage.setItem(LOCAL_STORAGE_KEYS.USER_DATA, JSON.stringify(data));
    }

    async refreshData(showNotification = false) {
        const latestData = await this.firebaseService.getData('user');
        this.setUserData(latestData);
        if (showNotification)
            this.notificationService.showNotification({
                heading: 'User data refreshed.',
                duration: 5000,
                leftBarColor: this.notificationService.color.green
            });
    }
}