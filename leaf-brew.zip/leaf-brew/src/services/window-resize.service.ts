import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

export interface Devices {
  isMobileView: boolean,
  isIpadMini: boolean
}

@Injectable({
  providedIn: 'root'
})
export class WindowResizeService {

  devices: Devices = { isMobileView: false, isIpadMini: false }
  private currentScreenStatus: BehaviorSubject<Devices> = new BehaviorSubject<Devices>(this.devices);
  currentScreenWidth!: number;

  setScreenWidth(width: number) {
    this.currentScreenWidth = width;
    if (width < 901) {
      if (width > 766)
        this.currentScreenStatus.next({ isMobileView: true, isIpadMini: true });
      else
        this.currentScreenStatus.next({ isMobileView: true, isIpadMini: false });
    }
    else {
      this.currentScreenStatus.next(this.devices);
    }
  }

  checkForWindowSize(): Observable<object> {
    return this.currentScreenStatus.asObservable();
  }
}
