import {
  AngularFireModule,
  FIREBASE_APP_NAME,
  FIREBASE_OPTIONS,
  FirebaseApp,
  ɵapplyMixins,
  ɵcacheInstance,
  ɵfirebaseAppFactory,
  ɵlazySDKProxy
} from "./chunk-P4NYQYAK.js";
import "./chunk-TO2L3J6M.js";
import "./chunk-ZPA46XRE.js";
import "./chunk-JAPO5GTQ.js";
import "./chunk-UFQEF2YE.js";
import "./chunk-NUUYPCC3.js";
import "./chunk-OPJDHPG3.js";
import "./chunk-IYEYSCYL.js";
import "./chunk-35ENWJA4.js";
export {
  AngularFireModule,
  FIREBASE_APP_NAME,
  FIREBASE_OPTIONS,
  FirebaseApp,
  ɵapplyMixins,
  ɵcacheInstance,
  ɵfirebaseAppFactory,
  ɵlazySDKProxy
};
